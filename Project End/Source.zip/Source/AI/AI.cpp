#include "AI.h"
#include "../Trace/Trace.h"
#include<Windows.h>

#include "../GlobalDefines.hpp"
#include "../AIManager/AIManager.h"
#include "../MemoryManager/MemoryManager.h"

#include "../ConversationManager/ConversationManager.h"


AI::AI()
	: displayCounter()
{}


AI::~AI()
{
	displayCounter = NULL;
}


void AI::Load()
{
	Trace::GetInstance().Write("AI::Load");
	MemoryManager::GetInstance().Load();
	ConversationManager::GetInstance().Load();
}


void AI::Init()
{
	Trace::GetInstance().Write("AI::Init");
	displayCounter = 0;
	MemoryManager::GetInstance().Init();

	ConversationManager::GetInstance().Init();
}


void AI::Update()
{
	Trace::GetInstance().Write("AI::Update");
	
	bool contains_command = false;

	if (ConversationManager::GetInstance().GrabInput())
	{
		// Check if the userInput contains any commands.
		for (unsigned int i = 0; i < command_list.size(); ++i)
		{
			if (command_list.at(i) == ConversationManager::GetInstance().GetUserInput())
			{
				ExecuteCommand(i);
				contains_command = true;
				break;
			}
		}

		if (!contains_command)
		{
			MemoryManager::GetInstance().Update();

			//if (!MemoryManager::GetInstance().Remember()) // Experimental for now.
				ConversationManager::GetInstance().Update();
		}
	}
}


void AI::Shutdown()
{
	Trace::GetInstance().Write("AI::Shutdown");
	MemoryManager::GetInstance().Shutdown();
	ConversationManager::GetInstance().Shutdown();

	displayCounter = NULL;
}


void AI::Unload()
{
	Trace::GetInstance().Write("AI::Unload");
	MemoryManager::GetInstance().Unload();
	ConversationManager::GetInstance().Unload();
}


void AI::ExecuteCommand(unsigned int index)
{
	Trace::GetInstance().Write("AI::ExecuteCommand");

	switch (index)
	{
	case 0: // _toggle_trace_display
		Trace::GetInstance().ToggleDisplay();
		break;

	case 1: // _write_new_data
		MemoryManager::GetInstance().StoreLearnedInformation();
		break;

	case 2: // _restart
		AIManager::GetInstance().SetNextState(AIState::Restarting);
		break;

	case 3: // _stop
		AIManager::GetInstance().SetNextState(AIState::Stopping);
		break;

	case 4: // _count_modified
		MemoryManager::GetInstance().CountModified();
		break;

	case 5: // _commands
		std::cout << "\nCommands are as follows: " << std::endl;
		for (UINT i = 0; i < command_list.size(); ++i)
			std::cout << command_list.at(i) << std::endl;

		std::cout << std::endl;
		break;

	case 6: // _recount_conversation
		ConversationManager::GetInstance().RecountConversation();
		break;

	default:
		break;
	}
}
