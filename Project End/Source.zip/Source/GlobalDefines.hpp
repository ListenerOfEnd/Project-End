#pragma once

/* ## KEYSTATE DEFINES ## */

#define ENTER '\n'
#define BACKSPACE '\b'
#define SPACE ' '

/* ## DATA TYPE DEFINES ## */

#define UINT unsigned int
#define LINT long int
#define LUINT long unsigned int

#define PCHAR *char
#define UDOUB unsigned double
#define LDOUB long double

#define LUDOUB long unsigned double
#define LL long long
